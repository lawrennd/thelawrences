/* Authors: Michael Meredith and Steve Maddock
 * 21 September 2005
 *
 * In this example the rotate button is used
 * to rotate the light source around the y axis.
 * The initial light position is (1.0,1.0,1.0).
 */

import java.awt.*;
import java.awt.event.*;
import net.java.games.jogl.*;
import net.java.games.jogl.util.GLUT;

public class M1 extends Frame implements ActionListener, ItemListener {

  private GLCanvas glcanvas;
  private M1GLSpace glspace;
  private Checkbox checkAxes, checkObjects;

  public static void main(String[] args) {
    M1 gl = new M1();
    gl.setVisible(true);
  }

  public M1() {
    setTitle("M1");
    setSize(600,500);
        
    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    } );

    MenuBar menuBar = new MenuBar();
    setMenuBar(menuBar);
      Menu fileMenu = new Menu("File");
        MenuItem quitItem = new MenuItem("Quit");
        quitItem.addActionListener(this);
        fileMenu.add(quitItem);
    menuBar.add(fileMenu);

    Panel p = new Panel(new GridLayout(2,1));
      Panel p1 = new Panel(new GridLayout(2,1));
        checkAxes = addCheckbox(p1, "axes on", this);
        checkObjects = addCheckbox(p1, "objects on", this);
      p.add(p1);
      p1 = new Panel();
        Button rotate = new Button("Rotate light");
        rotate.setActionCommand("Rotate");
        rotate.addActionListener(this);
        p1.add(rotate);
      p.add(p1);
    add(p, "East");
    
    glspace=new M1GLSpace();
    GLCapabilities capabilities=new GLCapabilities();
    glcanvas=GLDrawableFactory.getFactory().createGLCanvas(capabilities);
    glcanvas.addGLEventListener(glspace);

    add(glcanvas, "Center");
  }

  // With the Swing classes a JCheckBox is used in conjunction with 
  // an ActionListener.
  // In the AWT classes a Checkbox is used in conjunction with
  // an ItenListener.
  private Checkbox addCheckbox(Panel p, String s, ItemListener a) {
    Checkbox c = new Checkbox(s, true);
    c.addItemListener(a);
    p.add(c);
    return c;
  }

  public void actionPerformed(ActionEvent e) {
    if(e.getActionCommand().equalsIgnoreCase("rotate")) {
      glspace.incRotate();
      glcanvas.repaint();
    }
    else if(e.getActionCommand().equalsIgnoreCase("quit")) {
      System.exit(0);
    }
  }

  public void itemStateChanged(ItemEvent e) {
    Object source = e.getSource();
    if (source == checkAxes) {
      glspace.setAxesDisplay(checkAxes.getState());
      glcanvas.repaint();
    }
    else if (source == checkObjects) {
      glspace.setObjectsDisplay(checkObjects.getState());
      glcanvas.repaint();
    }
  }
}

class M1GLSpace implements GLEventListener {
    
  private final float INC_ROTATE=5.0f;
  private static final float NEAR_CLIP=0.1f;
  private static final float FAR_CLIP=100.0f;    

  private GLUT glut;
  private float rotate=0.0f;
  private boolean axesOn=true, objectsOn=true;

  public M1GLSpace() {
  }

  /** Called after OpenGL is init'ed */
  public void init (GLDrawable drawable) {
    GL gl = drawable.getGL(); 
    glut=new GLUT();

    gl.glClearColor(0.0f, 0.0f, 0.0f, 1.0f);  // black
    gl.glEnable(GL.GL_DEPTH_TEST);
    gl.glEnable(GL.GL_CULL_FACE);
    gl.glCullFace(GL.GL_BACK);
    gl.glShadeModel(GL.GL_SMOOTH);
    gl.glPolygonMode(GL.GL_FRONT_AND_BACK, GL.GL_FILL);
    gl.glEnable(GL.GL_NORMALIZE);
    gl.glEnable(GL.GL_LIGHTING);
  }

  /** Called by drawable to indicate mode or device has changed */
  public void displayChanged(GLDrawable drawable, boolean modeChanged, boolean deviceChanged) {
  }
      
  /** Called to indicate the drawing surface has been moved and/or resized  */
  public void reshape (GLDrawable drawable, int x, int y, int width, int height) {
    GL gl=drawable.getGL(); 
    GLU glu=drawable.getGLU(); 
    
    float fAspect=(float) width/height;
    float fovy=60.0f;

    gl.glViewport(0, 0, width, height);
    gl.glMatrixMode(GL.GL_PROJECTION);
    gl.glLoadIdentity();
    
    float top=(float) Math.tan(Math.toRadians(fovy*0.5))*NEAR_CLIP;
    float bottom=-top;
    float left=fAspect*bottom;
    float right=fAspect*top;
    
    gl.glFrustum(left, right, bottom, top, NEAR_CLIP, FAR_CLIP);
    gl.glMatrixMode(GL.GL_MODELVIEW);
  }

  /** Called by drawable to initiate drawing */
  public void display(GLDrawable drawable) {
    GL gl=drawable.getGL();
    GLU glu=drawable.getGLU();

    gl.glClear(GL.GL_COLOR_BUFFER_BIT|GL.GL_DEPTH_BUFFER_BIT);
    gl.glLoadIdentity();
    glu.gluLookAt(0.9f, 3.3f, 3.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f);
    
    gl.glPushMatrix();
      gl.glRotatef(rotate, 0.0f, 1.0f, 0.0f);
      light0(gl);
    gl.glPopMatrix();
    
    if (axesOn) 
      displayAxes(gl, glu, 2.2f, 1.8f, 1.6f);

    if (objectsOn) 
      displayObjects(gl, glu);
  }

  public void incRotate() {
    rotate+=INC_ROTATE;
  }

  public void setAxesDisplay(boolean b) {
    axesOn = b;
  }

  public void setObjectsDisplay(boolean b) {
    objectsOn = b;
  }

  private void light0(GL gl) {
    gl.glEnable(GL.GL_LIGHT0);
    // if w=0, then directional light at infinite distance
    float[] lightPosition = {1.0f, 1.0f, 1.0f, 0.0f}; 
    float[] ambient = {0.0f, 0.0f, 0.0f, 1.0f}; // default is none
    float[] whiteLight = {1.0f, 1.0f, 1.0f, 1.0f};
    gl.glLightfv(GL.GL_LIGHT0, GL.GL_POSITION, lightPosition);
    gl.glLightfv(GL.GL_LIGHT0, GL.GL_AMBIENT, ambient);
    gl.glLightfv(GL.GL_LIGHT0, GL.GL_DIFFUSE, whiteLight);
    gl.glLightfv(GL.GL_LIGHT0, GL.GL_SPECULAR, whiteLight);
  }    

  private void displayAxes(GL gl, GLU glu, float xLength, float yLength, float zLength) {
    // All axes will be set to same specular, shininess and emission settings.
    // Each axis will have will be set to different ambient and diffuse values.
    float[] matXAmbientDiffuse = {0.7f, 0.0f, 0.0f, 1.0f};
    float[] matYAmbientDiffuse = {0.0f, 0.7f, 0.0f, 1.0f};
    float[] matZAmbientDiffuse = {0.0f, 0.0f, 0.7f, 1.0f};
    float[] matSpecular = {1.0f, 1.0f, 1.0f, 1.0f};
    float[] matShininess = {32.0f};
    float[] matEmission = {0.0f, 0.0f, 0.0f, 1.0f};

    float cylinderRadius = 0.05f;
    float coneRadius = 0.05f;
    float coneHeight = 0.2f;
    
    int sphereslices = 20;
    int spherestacks = 20;
    int coneslices = 10;
    int conestacks = 10;
     
    gl.glMaterialfv(GL.GL_FRONT, GL.GL_AMBIENT_AND_DIFFUSE, matXAmbientDiffuse);
    gl.glMaterialfv(GL.GL_FRONT, GL.GL_SPECULAR, matSpecular);
    gl.glMaterialfv(GL.GL_FRONT, GL.GL_SHININESS, matShininess);
    gl.glMaterialfv(GL.GL_FRONT, GL.GL_EMISSION, matEmission);

    // x axis is half red
    gl.glPushMatrix();
      gl.glTranslatef(xLength/2.0f, 0.0f, 0.0f);
      gl.glScalef(xLength/2.0f, cylinderRadius, cylinderRadius);
      glut.glutSolidSphere(glu, 1.0f, sphereslices, spherestacks);
    gl.glPopMatrix();
    gl.glPushMatrix();
      gl.glTranslatef(xLength, 0.0f, 0.0f);
      gl.glRotatef(90.0f, 0.0f, 1.0f, 0.0f);
      // auxSolidCone(...) is defined with the point along the z axis
      // and the base on the xy plane.
      glut.glutSolidCone(glu, coneRadius, coneHeight, coneslices, conestacks);
    gl.glPopMatrix();

    // y axis is half green
    gl.glMaterialfv(GL.GL_FRONT, GL.GL_AMBIENT_AND_DIFFUSE, matYAmbientDiffuse);
    gl.glPushMatrix();
      gl.glTranslatef(0.0f, yLength/2.0f, 0.0f);
      gl.glScalef(cylinderRadius, yLength/2.0f, cylinderRadius);
      glut.glutSolidSphere(glu, 1.0f, sphereslices, spherestacks);
    gl.glPopMatrix();
    gl.glPushMatrix();
      gl.glTranslatef(0.0f, yLength, 0.0f);
      gl.glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
      glut.glutSolidCone(glu, coneRadius, coneHeight, coneslices, conestacks);
    gl.glPopMatrix();

    // z axis is half blue
    gl.glMaterialfv(GL.GL_FRONT, GL.GL_AMBIENT_AND_DIFFUSE, matZAmbientDiffuse);
    gl.glPushMatrix();
      gl.glTranslatef(0.0f, 0.0f, zLength/2.0f);
      gl.glScalef(cylinderRadius, cylinderRadius, yLength/2.0f);
      glut.glutSolidSphere(glu, 1.0f, sphereslices, spherestacks);
    gl.glPopMatrix();
    gl.glPushMatrix();
      gl.glTranslatef(0.0f, 0.0f, zLength);
      glut.glutSolidCone(glu, coneRadius, coneHeight, coneslices, conestacks);
    gl.glPopMatrix();
  }

  private void displayObjects(GL gl, GLU glu) {
    // Set new ambient, diffuse, specular and shininess values.
    // Can set ambient and diffuse separately,
    // but it is usual to set them to the same values.

    float[] matAmbientDiffuse = {0.5f, 0.2f, 0.8f, 1.0f};
    float[] matSpecular = {1.0f, 1.0f, 1.0f, 1.0f};
    float[] matShininess = {64.0f};
    float[] matEmission = {0.0f, 0.0f, 0.0f, 1.0f};
    gl.glMaterialfv(GL.GL_FRONT, GL.GL_AMBIENT_AND_DIFFUSE, matAmbientDiffuse);
    gl.glMaterialfv(GL.GL_FRONT, GL.GL_SPECULAR, matSpecular);
    gl.glMaterialfv(GL.GL_FRONT, GL.GL_SHININESS, matShininess);
    gl.glMaterialfv(GL.GL_FRONT, GL.GL_EMISSION, matEmission);
     
    int sphereslices = 10;
    int spherestacks = 10;

    gl.glPushMatrix();
      gl.glTranslatef(-1.0f, 0.0f, 0.0f);
      glut.glutSolidSphere(glu, 1.0f, sphereslices, spherestacks);
    gl.glPopMatrix();

// ****************************************************
// Add Exercise sheet 3 "Lighting in OpenGL" code here
// ****************************************************

    gl.glPushMatrix();
      gl.glTranslated(1.0f, 0.0f, 0.0f);
      glut.glutSolidSphere(glu, 1.0f, sphereslices, spherestacks);
    gl.glPopMatrix();
  }
}


