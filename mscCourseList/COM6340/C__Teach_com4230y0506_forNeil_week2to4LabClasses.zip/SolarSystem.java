/* Author: James Edge
 * 18 September 2002
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.Timer;

import net.java.games.jogl.*;
import net.java.games.jogl.util.GLUT;

public class SolarSystem extends Frame implements ActionListener, WindowListener
{
  private GLSolarSystemSpace glspace;
  private GLCanvas glcanvas;

  public static void main(String[] args)
  {
    SolarSystem ss=new SolarSystem();
    ss.setVisible(true);
  }

  public SolarSystem()
  {
    setSize(500, 500);
    setTitle("Solar System");
      
    MenuBar menu = new MenuBar();

    MenuItem mi;

    Menu file = new Menu("File");

    mi = new MenuItem("Exit");
    mi.addActionListener(this);
    file.add(mi);

    menu.add(file);

    Menu render = new Menu("Render");

    mi = new MenuItem("Point");
    mi.addActionListener(this);
    render.add(mi);
    
    mi = new MenuItem("Line");
    mi.addActionListener(this);
    render.add(mi);
    
    mi = new MenuItem("Fill");
    mi.addActionListener(this);
    render.add(mi);
    
    render.addSeparator();

    mi = new MenuItem("Flat");
    mi.addActionListener(this);
    render.add(mi);
    
    mi = new MenuItem("Smooth");
    mi.addActionListener(this);
    render.add(mi);

    menu.add(render);

    Menu animation = new Menu("Animation");

    mi = new MenuItem("Start");
    mi.addActionListener(this);
    animation.add(mi);

    mi = new MenuItem("Stop");
    mi.addActionListener(this);
    animation.add(mi);

    menu.add(animation);

    setMenuBar(menu);

    glspace=new GLSolarSystemSpace();
    GLCapabilities capabilities=new GLCapabilities();
    glcanvas=GLDrawableFactory.getFactory().createGLCanvas(capabilities);
    glcanvas.addGLEventListener(glspace);

    add(glcanvas, "Center");

    glcanvas.addKeyListener(glspace);
    glcanvas.addMouseListener(glspace);
    glcanvas.addMouseMotionListener(glspace);
    
    addWindowListener(this);
    
    Animator animator=new Animator(glcanvas);
    animator.start();
  }

  public void actionPerformed(ActionEvent e)
  {
    String cmd = e.getActionCommand();

    if (cmd.equalsIgnoreCase("Exit"))
      System.exit(0);
    else if (cmd.equalsIgnoreCase("Point"))
      glspace.setPolygonMode(GL.GL_POINT);
    else if (cmd.equalsIgnoreCase("Line"))
      glspace.setPolygonMode(GL.GL_LINE);
    else if (cmd.equalsIgnoreCase("Fill"))
      glspace.setPolygonMode(GL.GL_FILL);
    else if (cmd.equalsIgnoreCase("Flat"))
      glspace.setShadeModel(GL.GL_FLAT);
    else if (cmd.equalsIgnoreCase("Smooth"))
      glspace.setShadeModel(GL.GL_SMOOTH);
    else if (cmd.equalsIgnoreCase("Start"))
      glspace.startAnimation();
    else if (cmd.equalsIgnoreCase("Stop"))
      glspace.stopAnimation();
  }

	public void windowActivated(WindowEvent e){}
	public void windowClosed(WindowEvent e){}
	public void windowClosing(WindowEvent e){   System.exit(0); }
	public void windowDeactivated(WindowEvent e){}
	public void windowDeiconified(WindowEvent e){}
	public void windowIconified(WindowEvent e){}
	public void windowOpened(WindowEvent e){}
}

class GLSolarSystemSpace implements GLEventListener, KeyListener, MouseListener, MouseMotionListener
{
  public static final float NEAR_CLIP=1.0f;
  public static final float FAR_CLIP=20.0f;
  
  private boolean m_restart = false, m_playing;
  private int m_year0 = 0, m_year1 = 60, m_year2 = 240, m_polym = GL.GL_FILL, 
              m_shadem = GL.GL_SMOOTH, m_width, m_height;
  private double m_left, m_right, m_top, m_bottom;
  private float m_rotx = 0, m_roty = 0;
  private Point m_mouse;
  private GLUT glut;
  private long lasttime;

  public GLSolarSystemSpace()
  {
    m_playing=false;
  }

  public void decrementYear()
  {
    m_year0=(m_year0-10)%360;
    m_year1=(m_year1-5)%360;
    m_year2=(m_year2-2)%360;
  }

  public void incrementYear()
  {
    m_year0=(m_year0+10)%360;
    m_year1=(m_year1+5)%360;
    m_year2=(m_year2+2)%360;
  }

  public void init (GLDrawable drawable) {
    GL gl = drawable.getGL();
    glut=new GLUT();

    gl.glClearColor(0.0f, 0.0f, 0.0f, 1.0f); //black
  }

  /** Called by drawable to indicate mode or device has changed */
  public void displayChanged(GLDrawable drawable, boolean modeChanged, boolean deviceChanged) {
  }
      
  /** Called to indicate the drawing surface has been moved and/or resized  */
  public void reshape (GLDrawable drawable, int x, int y, int width, int height) {
    GL gl=drawable.getGL(); 
    GLU glu=drawable.getGLU(); 
    
    float fAspect=(float) width/height;
    float fovy=60.0f;

    gl.glViewport(0, 0, width, height);
    gl.glMatrixMode(GL.GL_PROJECTION);
    gl.glLoadIdentity();
    
    float top=(float) Math.tan(Math.toRadians(fovy*0.5))*NEAR_CLIP;
    float bottom=-top;
    float left=fAspect*bottom;
    float right=fAspect*top;
    
    gl.glFrustum(left, right, bottom, top, NEAR_CLIP, FAR_CLIP);
    gl.glMatrixMode(GL.GL_MODELVIEW);
    
    m_width=width;
    m_height=height;
  }
  
  public void display(GLDrawable drawable) 
  {
    GL gl = drawable.getGL();
    GLU glu = drawable.getGLU();

    gl.glEnable(GL.GL_POINT_SMOOTH);
    gl.glEnable(GL.GL_LINE_SMOOTH);

    gl.glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    gl.glClear(GL.GL_COLOR_BUFFER_BIT|GL.GL_DEPTH_BUFFER_BIT);
    gl.glPolygonMode(GL.GL_FRONT_AND_BACK, m_polym);
    gl.glShadeModel(m_shadem);
    gl.glPointSize(2.0f);
    gl.glLineWidth(1.0f);

    gl.glLoadIdentity();
    glu.gluLookAt(0.0f, 0.0f, 6.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f);
                
    gl.glPushMatrix();
      light(gl);
      gl.glRotatef(m_rotx, 0.0f, 1.0f, 0.0f);
      gl.glRotatef(m_roty, 1.0f, 0.0f, 0.0f);

      gl.glPushMatrix();
        float[] sun_amb={1.0f, 1.0f, 0.0f};
        float[] sun_spec={0.0f, 0.0f, 0.0f};

        gl.glMaterialfv(GL.GL_FRONT_AND_BACK, GL.GL_AMBIENT, sun_amb);
        gl.glMaterialfv(GL.GL_FRONT_AND_BACK, GL.GL_SPECULAR, sun_spec);
        gl.glMateriali(GL.GL_FRONT_AND_BACK, GL.GL_SHININESS, 124);
        glut.glutSolidSphere(glu, 1.0f, 20, 20);

        gl.glPushMatrix();
          float[] planet0_amb={0.0f, 1.0f, 0.0f};
          float[] planet0_spec={0.4f, 0.4f, 0.4f};

          gl.glRotatef((float)m_year0, 1.0f, 1.0f, 1.0f);
          gl.glTranslatef(-1.0f, 1.0f, 0.0f);
          gl.glMaterialfv(GL.GL_FRONT_AND_BACK, GL.GL_AMBIENT, planet0_amb);
          gl.glMaterialfv(GL.GL_FRONT_AND_BACK, GL.GL_SPECULAR, planet0_spec);
          gl.glMateriali(GL.GL_FRONT_AND_BACK, GL.GL_SHININESS, 124);
          glut.glutSolidSphere(glu, 0.1f, 20, 20);

          gl.glPopMatrix();
            gl.glPushMatrix();
              float[] planet1_amb={0.0f, 0.0f, 1.0f};
              float[] planet1_spec={0.4f, 0.4f, 0.4f};

              gl.glRotatef(m_year1, 1.0f, 1.0f, 1.0f);
              gl.glTranslatef(-1.3f, 1.3f, 0.0f);
              gl.glMaterialfv(GL.GL_FRONT_AND_BACK, GL.GL_AMBIENT, planet1_amb);
              gl.glMaterialfv(GL.GL_FRONT_AND_BACK, GL.GL_SPECULAR, planet1_spec);
              gl.glMateriali(GL.GL_FRONT_AND_BACK, GL.GL_SHININESS, 124);
              glut.glutSolidSphere(glu, 0.2f, 20, 20);

              gl.glPopMatrix();
                float[] planet2_amb = {1.0f, 0.0f, 0.0f};
                float[] planet2_spec = {0.4f, 0.4f, 0.4f};

                gl.glRotatef(m_year2, 1.0f, 1.0f, 1.0f);
                gl.glTranslatef(-1.7f, 1.7f, 0.0f);
                gl.glMaterialfv(GL.GL_FRONT_AND_BACK, GL.GL_AMBIENT, planet2_amb);
                gl.glMaterialfv(GL.GL_FRONT_AND_BACK, GL.GL_SPECULAR, planet2_spec);
                gl.glMateriali(GL.GL_FRONT_AND_BACK, GL.GL_SHININESS, 124);
                glut.glutSolidSphere(glu, 0.3f, 20, 20);
                
                float[] disk_amb = {0.5f, 0.5f, 0.0f};
                float[] disk_spec = {0.0f, 0.0f, 0.0f};
                gl.glMaterialfv(GL.GL_FRONT_AND_BACK, GL.GL_AMBIENT, disk_amb);
                gl.glMaterialfv(GL.GL_FRONT_AND_BACK, GL.GL_SPECULAR, disk_spec);
                gl.glMateriali(GL.GL_FRONT_AND_BACK, GL.GL_SHININESS, 0);
                glut.glutSolidTorus(gl, 0.1f, 0.3f, 20, 20);

              gl.glPopMatrix();
            gl.glPopMatrix();
           gl.glPopMatrix();
        gl.glPopMatrix();
      gl.glPopMatrix();
    gl.glPopMatrix();
    
    if (m_playing)
    {
      long now=System.currentTimeMillis();
      if (now-lasttime>25)
      {
        incrementYear();
        lasttime=now;
      }
    }
  }
  

  private void light(GL gl)
  {
    float[] pos = {1.0f, 1.0f, 1.0f, 1.0f};
    float[] amb = {0.6f, 0.6f, 0.6f, 1.0f};
        
    gl.glEnable(GL.GL_LIGHTING);
    gl.glEnable(GL.GL_DEPTH_TEST);

    gl.glEnable(GL.GL_LIGHT0);
    gl.glLightfv(GL.GL_LIGHT0, GL.GL_POSITION, pos);
    gl.glLightfv(GL.GL_LIGHT0, GL.GL_AMBIENT, amb);
  }

  public void setPolygonMode(int pm)
  {   
    m_polym = pm;
  }

  public void setShadeModel(int sm)
  {   
    m_shadem = sm;
  }

  public void startAnimation()
  {   
    m_playing=true;
    lasttime=System.currentTimeMillis();
  }

  public void stopAnimation()
  {   m_playing=false; }

  public void keyPressed(KeyEvent e)
  {
    char c=e.getKeyChar();

    if(c=='y')
      incrementYear();
    else if(c=='Y')
      decrementYear();
  }
  
  public void keyReleased(KeyEvent e){}
  public void keyTyped(KeyEvent e){}

  public void mousePressed(MouseEvent e)
  {
    if(m_playing)
    {
      m_playing=false;
      m_restart = true;
    }
  }

  public void mouseReleased(MouseEvent e)
  {
    if(m_restart)
    {
      m_playing=true;
      m_restart = false;
    }
  }

  public void mouseClicked(MouseEvent e){}
  public void mouseEntered(MouseEvent e){}
  public void mouseExited(MouseEvent e){}

  public void mouseDragged(MouseEvent e)
  {
    Point ms = e.getPoint();

    float xp = (float)(ms.x-m_mouse.x)/m_width;
    float yp = (float)(ms.y-m_mouse.y)/m_height;
    
    m_rotx += (xp*180.0f);
    m_roty += (yp*180.0f);

    m_mouse = ms;
  }

  public void mouseMoved(MouseEvent e)
  {   
    m_mouse = e.getPoint(); 
  }
}
