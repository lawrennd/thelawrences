import java.awt.*;
import java.awt.event.*; 
import net.java.games.jogl.*;
import net.java.games.jogl.util.GLUT;

public class T1 extends Frame implements ActionListener {

  private T1GLSpace glspace;
  private GLCanvas glcanvas;

  public static void main(String[] args) {
    T1 gl = new T1();
    gl.setVisible(true);
  }
    
  public T1() {
    super("T1");
    setSize(500, 500);
        
    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    } );

    MenuBar menuBar=new MenuBar();
    setMenuBar(menuBar);
      Menu fileMenu = new Menu("File");
        MenuItem quitItem = new MenuItem("Quit");
        quitItem.addActionListener(this);
        fileMenu.add(quitItem);
    menuBar.add(fileMenu);

    Panel p = new Panel();
      Button rotate = new Button("Rotate");
      rotate.addActionListener(this);
      p.add(rotate);
    add(p, "South");

    glspace = new T1GLSpace();
    GLCapabilities capabilities = new GLCapabilities();
    glcanvas = GLDrawableFactory.getFactory().createGLCanvas(capabilities);
    glcanvas.addGLEventListener(glspace);

    add(glcanvas, "Center");
  }

  public void actionPerformed(ActionEvent e) {
    if(e.getActionCommand().equalsIgnoreCase("rotate")) {
      glspace.rotate();
      glcanvas.repaint();
    }
    else if(e.getActionCommand().equalsIgnoreCase("quit"))
      System.exit(0);
  }
}

class T1GLSpace implements GLEventListener {
  
  private static final float INC_ROTATE=5.0f;
  private static final float NEAR_CLIP=0.1f;
  private static final float FAR_CLIP=100.0f;    
  
  private GLUT glut;
  private float rotate=0.0f;

  public T1GLSpace() {
  }

  public void rotate() {
    rotate+=INC_ROTATE;
  }
  
  /*
   * METHODS DEFINED BY GLEventListener
   */
  
  /** Called by drawable to initiate drawing */
  public void display(GLDrawable drawable) {
    GL gl = drawable.getGL();
    GLU glu = drawable.getGLU();

    gl.glClear(GL.GL_COLOR_BUFFER_BIT);
    gl.glLoadIdentity();
    glu.gluLookAt(1.2f, 1.0f, 2.5f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f);

    gl.glBegin(GL.GL_LINES);
      gl.glColor3f(1.0f, 0.0f, 0.0f);
      gl.glVertex3f(0.0f, 0.0f, 0.0f);
      gl.glVertex3f(1.5f, 0.0f, 0.0f);
      gl.glColor3f(0.0f, 1.0f, 0.0f);
      gl.glVertex3f(0.0f, 0.0f, 0.0f);
      gl.glVertex3f(0.0f, 1.5f, 0.0f);
      gl.glColor3f(0.0f, 0.0f, 1.0f);
      gl.glVertex3f(0.0f, 0.0f, 0.0f);
      gl.glVertex3f(0.0f, 0.0f, 1.5f);
    gl.glEnd();

    gl.glColor3f(1.0f, 1.0f, 1.0f);
    gl.glRotatef(rotate, 0.0f, 0.0f, 1.0f);
    glut.glutWireCube(gl, 1);
  }
    
  /** Called by drawable to indicate mode or device has changed */
  public void displayChanged(GLDrawable drawable, boolean modeChanged, boolean deviceChanged) {
  }
  
  /** Called after OpenGL is init'ed */
  public void init (GLDrawable drawable) {
    GL gl = drawable.getGL(); 

    gl.glClearColor(0.0f, 0.0f, 0.0f, 1.0f); //black
    glut = new GLUT();
  }
    
  /** Called to indicate the drawing surface has been moved and/or resized  */
  public void reshape (GLDrawable drawable, int x, int y, int width, int height) {
    GL gl = drawable.getGL(); 
    GLU glu = drawable.getGLU(); 
    
    float fAspect=(float) width/height;
    float fovy=60.0f;

    gl.glViewport(0, 0, width, height);
    gl.glMatrixMode(GL.GL_PROJECTION);
    gl.glLoadIdentity();
    
    float top=(float) Math.tan(Math.toRadians(fovy*0.5))*NEAR_CLIP;
    float bottom=-top;
    float left=fAspect*bottom;
    float right=fAspect*top;
    
    gl.glFrustum(left, right, bottom, top, NEAR_CLIP, FAR_CLIP);
    gl.glMatrixMode(GL.GL_MODELVIEW);
  }
}
