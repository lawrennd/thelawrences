import java.awt.*;
import java.awt.event.*;
import net.java.games.jogl.*;

public class S1 extends Frame implements ActionListener {

  public final static int WIDTH=640;
  public final static int HEIGHT=480;

  private GLCanvas glcanvas;
  private S1GLSpace glspace;
  
  public static void main(String[] args) {
    S1 gl = new S1();
    gl.setVisible(true);
  }

  public S1() {
    super("S1");
    setSize(WIDTH, HEIGHT);
        
    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
      System.exit(0);
      }
    } );

    MenuBar menuBar=new MenuBar();
    setMenuBar(menuBar);
      Menu fileMenu=new Menu("File");
        MenuItem quitItem=new MenuItem("Quit");
        quitItem.addActionListener(this);
        fileMenu.add(quitItem);
    menuBar.add(fileMenu);

    Panel p=new Panel();
      Button redraw=new Button("Draw");
      redraw.addActionListener(this);
    p.add(redraw);

    add(p, "South");
    
    glspace=new S1GLSpace();
    GLCapabilities capabilities=new GLCapabilities();
    glcanvas=GLDrawableFactory.getFactory().createGLCanvas(capabilities);
    glcanvas.addGLEventListener(glspace);

    add(glcanvas, "Center");
  }

  public void actionPerformed(ActionEvent e) {
    if(e.getActionCommand().equalsIgnoreCase("draw"))
      glcanvas.repaint();
    else if(e.getActionCommand().equalsIgnoreCase("quit"))
      System.exit(0);
  }
}

class S1GLSpace implements GLEventListener {
    
  private static final float NEAR_CLIP=0.1f;
  private static final float FAR_CLIP=100.0f;    

  public S1GLSpace() {
  }

  /** Called after OpenGL is init'ed */
  public void init (GLDrawable drawable) {
    GL gl = drawable.getGL(); 

    gl.glClearColor(0.0f, 0.0f, 0.0f, 1.0f); //black
  }

  /** Called by drawable to indicate mode or device has changed */
  public void displayChanged(GLDrawable drawable, boolean modeChanged, boolean deviceChanged) {
  }
      
  /** Called to indicate the drawing surface has been moved and/or resized  */
  public void reshape (GLDrawable drawable, int x, int y, int width, int height) {
    GL gl=drawable.getGL(); 
    GLU glu=drawable.getGLU(); 
    
    float fAspect=(float) width/height;
    float fovy=60.0f;

    gl.glViewport(0, 0, width, height);
    gl.glMatrixMode(GL.GL_PROJECTION);
    gl.glLoadIdentity();
    
    float top=(float) Math.tan(Math.toRadians(fovy*0.5))*NEAR_CLIP;
    float bottom=-top;
    float left=fAspect*bottom;
    float right=fAspect*top;
    
    gl.glFrustum(left, right, bottom, top, NEAR_CLIP, FAR_CLIP);
    gl.glMatrixMode(GL.GL_MODELVIEW);
  }

  /** Called by drawable to initiate drawing */
  public void display(GLDrawable drawable) {
    GL gl=drawable.getGL();
    GLU glu=drawable.getGLU();

    gl.glClear(GL.GL_COLOR_BUFFER_BIT);
    gl.glLoadIdentity();
    glu.gluLookAt(1.2f, 1.0f, 2.5f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f);

    gl.glBegin(GL.GL_TRIANGLES);
      gl.glColor3f(1.0f, 0.0f, 0.0f);     // red
      gl.glVertex3f(-1.0f, -1.0f, 0.0f);  // x, y, z values
                                  // glVertex2f(-1,-1) could be used,
                                  // but openGL would still consider
                                  // this to be (-1,-1,0)
                                  // (i.e. a default z value of 0 is assumed)
      gl.glColor3f(0.0f, 1.0f, 0.0f);     // green
      gl.glVertex3f(0.0f, 1.0f, 0.0f);
      gl.glColor3f(0.0f, 0.0f, 1.0f);     // blue
      gl.glVertex3f(1.0f, -1.0f, 0.0f);
    gl.glEnd();
  }
}


