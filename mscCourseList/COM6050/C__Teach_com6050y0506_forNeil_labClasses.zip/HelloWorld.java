// HelloWorld.java
// Traditional Hello World program!

public class HelloWorld {

  public static void main( String[] arg ){

    String helloString = "Hello";
    String worldString = "World!";

    // The command below doesn't work, because the method 
    // has no argument. Using the text editor, either replace 
    // helloWorldString with helloString + " " + worldString
    // or insert a line like the one below
    // String helloWorldString = helloString + " " + worldString;

    System.out.println( helloWorldString );
  }
} 
