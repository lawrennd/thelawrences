
public class TypeCast{
   
  public static void main(String[] args){
    int integer1 = 4;
    int integer2 = 5;
    int average1 = (integer1 + integer2) / 2;
    double average2 = (integer1 + integer2) / 2;
    double average3 = (integer1 + integer2) / 2.0;
    double average4 = (integer1 + integer2) / (float) 2;
    double average5 = (float) (integer1 + integer2) / 2;

    System.out.println( average1 );
    System.out.println( average2 );
    System.out.println( average3 );
    System.out.println( average4 );
    System.out.println( average5 );
  }
}
