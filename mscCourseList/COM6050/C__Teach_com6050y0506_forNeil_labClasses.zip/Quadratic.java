// Quadratic.java
//
// solves quadratic equations for x given a*x*x + b*x + c = 0
//
// Richard Clayton

public class Quadratic{

  public static void main( String[] arg){

    int    aInt =    1,    bInt = 2, cInt =    1;
    double aDouble = 1, bDouble = 2, cDouble = 1;

    double x1, x2;

    // work out solution with int types
    aInt -= 1/2;
    x1 = (-1 * bInt + Math.sqrt(bInt*bInt - 4 * aInt * cInt)) / (2 * aInt);
    x2 = (-1 * bInt - Math.sqrt(bInt*bInt - 4 * aInt * cInt)) / (2 * aInt);
    System.out.println("Solution with integer types is x1 = " + x1 + ", and x2 = " + x2 );

    // work out solution with double types
    aDouble -= 0.5;
    x1 = (-1 * bDouble + Math.sqrt(bDouble*bDouble - 4 * aDouble * cDouble)) / (2 * aDouble);
    x2 = (-1 * bDouble - Math.sqrt(bDouble*bDouble - 4 * aDouble * cDouble)) / (2 * aDouble);
    System.out.println("Solution with double types is  x1 = " + x1 + ", and x2 = " + x2 );
		
  }
}

