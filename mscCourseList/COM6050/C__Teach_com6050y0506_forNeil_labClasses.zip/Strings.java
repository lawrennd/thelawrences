

public class Strings {

  public static void main(String[] args) {
    String part1 = "Hello ";
    String part2 = "World!";
    String part3 = "Hello ";
    String sub = "lo Wxo";
    String conc;

    int length;
    int startindex;

    System.out.println("part1=" + part1 + ", and part2=" + part2 );
    conc = part1 + part2;
    length = conc.length();
    System.out.println("Concatenation ... :" + conc );
    System.out.println("length ...        :" + length + " characters");

    if (part1.equals(part3))
    {
      System.out.println("Strings '" + part1 + "' and '" + part3 + "' are equal");
    }
    if (!part1.equals(part2))
    {
      System.out.println("Strings '" + part1 + "' and '" + part2 + "' are not equal");
    }
    if (part2.endsWith("!"))
    {
      System.out.println("String '" + part2 + "' ends with '!'");
    }
    startindex = conc.indexOf(sub);
    if (startindex >= 0)
    {
      System.out.println("String '" + conc + "' contains the string '" + sub + "' starting at index " + startindex);
    }
    else
    {
      System.out.println("String '" + conc + "' does not contain the string '" + sub + "'");
    }
  }
}
