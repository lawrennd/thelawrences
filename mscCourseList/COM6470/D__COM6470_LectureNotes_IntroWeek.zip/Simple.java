/*
	A simple Java program
	Written by: Guy J. Brown
	First written: 19/8/02
	Last rewritten: 24/8/02
*/

public class Simple {
	public static void main(String[] arg) {
		System.out.print("Running a Java application");
		System.out.println("...finished.");
		} 
	} 