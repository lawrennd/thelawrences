/*
	A fun exercise
	Written by: Guy J. Brown
	First written: 19/8/02
	Last rewritten: 24/8/02
*/

public class FunExercise {
	public static void main(String[] arg) {
		System.out.print("Java programming");
		System.out.println(" is ");
		System.out.print("F");
		System.out.print("U");
		System.out.println("N");
		}
	}