/*
	Using nested for loops to make a grid of cubes
	One loop counts through the x coordinates of each cube, 
	the other counts through the y coordinates
	Constants could be used for the cube size, margins etc
	Written by: Guy J. Brown
	First written: 29/8/98
	Last rewritten: 30/9/02
*/

import sheffield.*;

public class Graticule {

	// constant declarations
	
	public static void main(String args[]) {

		final int WIN_SIZE = 300; 	// window size

		EasyGraphics g=new EasyGraphics(WIN_SIZE,WIN_SIZE);
		for (int x=50; x<=250; x+=10) 
			for (int y=50; y<=250; y+=10) {
				// draw a cube of width and height 8 pixels at (x,y)
				g.moveTo(x,y); g.lineTo(x+8,y);
				g.lineTo(x+8,y+8); g.lineTo(x,y+8);
				g.lineTo(x,y);
				}
			}
		}