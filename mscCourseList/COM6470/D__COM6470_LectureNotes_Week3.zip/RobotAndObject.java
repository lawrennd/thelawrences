/*
	A robot halves the distance between itself and an object,
	until the object is reached. 
	Written by: Guy J. Brown
	First written: 31/8/98
	Last rewritten: 30/9/02
*/

import sheffield.*;

public class RobotAndObject {
	
	public static void main(String args[]) {

		final double MIN_DISTANCE = 0.5;

		EasyReader keyboard = new EasyReader();
		double distance = keyboard.readDouble("Enter the distance: ");
		while (distance>MIN_DISTANCE) {
			System.out.println("Distance from object is "																		+distance);
			System.out.println("Moving...");
			distance = distance/2;
			}
		System.out.println("I reached the object, distance is "+distance);
		}
	}