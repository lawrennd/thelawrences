/*
	Using a for loop to make a spiders web
	We use a loop to count coordinates in steps of 10
	Written by: Guy J. Brown
	First written: 29/8/98
	Last rewritten: 30/9/02
*/

import sheffield.*;

public class WebMaker {

	public static void main(String args[]) {

		final int WIN_SIZE = 300; 	// size of window
		final int STEP_SIZE = 10; 	// step size between lines

		EasyGraphics g=new EasyGraphics(WIN_SIZE,WIN_SIZE);
		for (int x=0; x<=WIN_SIZE; x+=STEP_SIZE) {
			g.lineBetween(x,0,WIN_SIZE,x);
			g.lineBetween(x,WIN_SIZE,0,x);
			g.lineBetween(x,WIN_SIZE,WIN_SIZE,WIN_SIZE-x);
			g.lineBetween(0,WIN_SIZE-x,x,0);
			}
		}
	}