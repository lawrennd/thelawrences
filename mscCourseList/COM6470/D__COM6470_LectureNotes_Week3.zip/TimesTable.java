/*
	Computes the multiplication table for a given integer
	Demonstration of the for loop
	Written by: Guy J. Brown
	First written: 31/8/98
	Last rewritten: 30/9/02
*/

import sheffield.*;

public class TimesTable {
	
	public static void main(String args[]) {

		final int MAX_TABLE = 12; 	// number of rows in table

		int number;
		EasyReader keyboard = new EasyReader();
		number = keyboard.readInt("Enter a number: ");
		for (int i=0; i<=MAX_TABLE; i++) {
			System.out.print(i+" times "+number+" = ");
			System.out.println(number*i);
			}
		}
	}