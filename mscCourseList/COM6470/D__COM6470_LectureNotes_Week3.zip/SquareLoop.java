/*
	Computes the square of a sequence of numbers
	User input terminates the program
	Note: we don�t use readChar because of a bug on the Windows 
	2000 platform
	Written by: Guy J. Brown
	First written: 31/8/98
	Last rewritten: 2/10/03
*/

import sheffield.*;

public class SquareLoop {
	public static void main(String args[]) {
            String response;
            EasyReader keyboard = new EasyReader();
            do {
                int number = keyboard.readInt("Enter a number: ");
                System.out.println("The square of your number is "+number*number);
                response = keyboard.readString("Another try? (y/n) ");
                } while (response.equals("y"));
            System.out.println("Finished");
            }
	}