/*
	A robot halves the distance between itself and an object,
	until the object is reached or the battery runs out. 
	Written by: Guy J. Brown
	First written: 31/8/98
	Last rewritten: 30/9/02
*/

import sheffield.*;

public class RobotWithBattery {
	
	public static void main(String args[]) {

	 	final double MIN_POWER = 0.1;
	 	final double MIN_DISTANCE = 0.5;

		EasyReader keyboard = new EasyReader();
		double distance = keyboard.readDouble("Enter the distance: ");
		double batteryPower = keyboard.readDouble("Enter the battery power: ");
		while ((distance>MIN_DISTANCE) && (batteryPower>MIN_POWER)) {
			System.out.println("Distance from object is "+distance);
			System.out.println("Battery power is "+batteryPower);
			System.out.println("Moving...");
			distance = distance/2;
			batteryPower = batteryPower/2;
			}
		if (batteryPower<=MIN_POWER) 
			System.out.println("I ran out of power!");
		else 
			System.out.println("I reached it, distance is "+distance);
		}	
	}
	
