/*
        Calculate the carpet and wallpaper needed
        Written by: Guy J. Brown
        First written: 19/8/02
        Last rewritten: 24/8/02
*/

public class WallPaper {

	public static void main(String[] arg) {
	
		int length=2, width=4, height=5;
		int carpetSize, wallpaperSize;
		
		// do the calculations

		carpetSize = length*width;
		wallpaperSize = 2*height*(length+width);
		
		// print the result

		System.out.print("Your room needs ");
		System.out.print(carpetSize); 
		System.out.print(" square metres of carpet and ");
		System.out.print(wallpaperSize);
		System.out.println(" square metres of wallpaper");
		
		} 
	}