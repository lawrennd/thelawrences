/*
        Calculate the area of a field
        Written by: Guy J. Brown
        First written: 19/8/02
        Last rewritten: 12/9/02
*/

public class CropArea {
	public static void main(String[] arg) {
	
		double width = 3.2;	 // width of field in metres
		double length = 7.8; // length of field in metres

		// compute the area
		
		double area = width*length;
		
		// write the result
		
		System.out.print("Your field has an area of ");
		System.out.print(area);
		System.out.println(" metres squared.");
		
		} 
	}