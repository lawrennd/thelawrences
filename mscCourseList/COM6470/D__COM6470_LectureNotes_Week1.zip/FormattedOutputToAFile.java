/*
	Formatted output to a file
	Written by: Guy J. Brown
	First written: 16/9/02
	Last rewritten: 16/9/02
*/

import sheffield.*;

public class FormattedOutputToAFile {

	public static void main(String[] arg) {

		EasyWriter screen = new EasyWriter("output.txt");

		double x = 2.184918284982;
		double y = 127.318291823;
    
		screen.println(x);      // same as System.out.println(x)
    
		screen.println(x,3);    // display three decimal places
    
		screen.println(x,5,10); // display five decimal places 
					// in a field of 10 spaces
		screen.println(y,5,10);

  		}
	}