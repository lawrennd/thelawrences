/*
	Demonstration of EasyReader readInt method
	Written by: Guy J. Brown
	First written: 16/9/02
	Last rewritten: 16/9/02
*/

import sheffield.*;

public class WallPaperTwo {

	public static void main(String[] arg) {

		EasyReader keyboard = new EasyReader();

		// get the dimensions of the room from the user

		int length = keyboard.readInt("Enter the length: ");
		int width = keyboard.readInt("Enter the width: ");
		int height = keyboard.readInt("Enter the height: ");

		// do the calculations

		int carpetSize = length*width;
		int wallpaperSize = 2*height*(length+width);

 		// print the result

		System.out.print("Your room needs ");
		System.out.print(carpetSize);
		System.out.print(" square metres of carpet and ");
		System.out.print(wallpaperSize);
		System.out.println(" square metres of wallpaper.");
  
		} 
	}