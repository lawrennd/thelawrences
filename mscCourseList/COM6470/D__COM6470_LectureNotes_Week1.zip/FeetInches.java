/*
        Conversion between feet/inches and cm
        Written by: Guy J. Brown
        First written: 19/8/02
        Last rewritten: 24/8/02
*/

public class FeetInches {

	public static void main(String[] args) {

		final double CM_PER_INCH = 2.54;
		final int INCHES_PER_FOOT = 12;

		int numFeet = 3;
		int numInches = 2;
		double numCm;

		numCm = CM_PER_INCH*(numInches+numFeet*INCHES_PER_FOOT);

		System.out.print(numFeet);
		System.out.print(" feet and ");
		System.out.print(numInches);
		System.out.print(" inches is ");
		System.out.print(numCm);
		System.out.println(" cm");

		}
	}