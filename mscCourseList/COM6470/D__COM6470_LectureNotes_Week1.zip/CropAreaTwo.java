/*
	Demonstration of EasyReader
	Written by: Guy J. Brown
	First written: 16/9/02
	Last rewritten: 16/9/02
*/

import sheffield.*;

public class CropAreaTwo {

	public static void main(String[] arg) {

		EasyReader keyboard = new EasyReader();

    		// read the length and width of the field from the user

		System.out.println("Enter the width of the field: ");
		double width = keyboard.readDouble();
		System.out.println("Enter the length of the field: ");
		double length = keyboard.readDouble();

    		// compute the area

    		double area = width*length;

    		// write the result

		System.out.print("Your field has an area of ");
		System.out.print(area);
		System.out.println(" metres squared.");

		} 
	}