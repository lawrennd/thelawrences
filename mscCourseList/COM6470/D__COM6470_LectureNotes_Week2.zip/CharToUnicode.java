/*
        Convert a character to a unicode number
        Written by: Guy J. Brown
        First written: 18/9/02
        Last rewritten: 18/9/02
*/

import sheffield.*;

public class CharToUnicode {

	public static void main(String[] args) {

		EasyReader keyboard = new EasyReader();
 
		char ch = keyboard.readChar("Type a character: ");

		System.out.print("Unicode number is: ");
		System.out.println((int)ch);

		}
	}