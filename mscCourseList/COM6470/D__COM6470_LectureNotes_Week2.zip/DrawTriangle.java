/*
        Draw a triangle
        Written by: Guy J. Brown
        First written: 19/9/02
        Last rewritten: 19/9/02
*/

import sheffield.*;

public class DrawTriangle {

	public static void main(String[] args) {
		
		final double theta = Math.PI/3.0;
		
		EasyReader keyboard = new EasyReader();
		double sideLen = keyboard.readDouble("Enter the side length: ");

		EasyGraphics g = new EasyGraphics();

		g.moveTo(10,10);
		g.lineTo(10+sideLen*Math.cos(theta),10+sideLen*Math.sin(theta));
		g.lineTo(10+sideLen,10); 
		g.lineTo(10,10);

		}
		
	}

