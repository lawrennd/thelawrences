/*
        Finding the length of a string
        Written by: Guy J. Brown
        First written: 19/9/02
        Last rewritten: 19/9/02
*/

import sheffield.*;

public class StringLength {

	public static void main( String[] args) {

		EasyReader keyboard = new EasyReader();
		String s1;

		s1 = keyboard.readString("Enter a string: ");

		System.out.println("Length is: "+s1.length());

		}
	}

