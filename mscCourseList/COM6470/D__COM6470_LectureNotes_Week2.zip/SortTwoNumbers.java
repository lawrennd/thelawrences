/*
	Sort two numbers - first version
 	Written by: Guy J. Brown
        First written: 27/9/02
        Last rewritten: 27/9/02
*/

import sheffield.*;

public class SortTwoNumbers {

	public static void main(String[] args) {

		// variable declarations
		int larger, smaller, temporary, sum, difference;
		EasyReader keyboard = new EasyReader();

		// get two numbers from the keyboard
		larger = keyboard.readInt("Enter first integer: ");
		smaller = keyboard.readInt("Enter second integer: ");

		// swap if necessary
		if (larger < smaller) {
			temporary = larger;
			larger = smaller;
			smaller = temporary;
			}

		sum = larger+smaller;
		difference = larger-smaller;
		System.out.println("The sum is "+sum);
		System.out.println("The difference is "+difference);
		System.out.println("Larger is "+larger+" and smaller is "+smaller);
	}
}