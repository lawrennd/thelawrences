/*
        Convert a number to a unicode character
        Written by: Guy J. Brown
        First written: 18/9/02
        Last rewritten: 18/9/02
*/

import sheffield.*;

public class UnicodeToChar {

	public static void main(String[] args) {

		EasyReader keyboard = new EasyReader();
 
		int number = keyboard.readInt("Type a decimal Unicode number: ");
  
		System.out.print("char is: ");
		System.out.println((char)number);

		}
	}