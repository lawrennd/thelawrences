/*
        Draw a house
        Written by: Guy J. Brown
        First written: 19/9/02
        Last rewritten: 19/9/02
*/

import sheffield.*;

public class House {

	public static void main(String[] args) {

		EasyGraphics g = new EasyGraphics(200,200);	
		g.moveTo(10,140);
		g.lineTo(10,10);
		g.lineTo(190,10);
		g.lineTo(190,140);
		g.lineTo(10,140);
		g.lineTo(100,190);
		g.lineTo(190,140);
	
		}
		
	}
