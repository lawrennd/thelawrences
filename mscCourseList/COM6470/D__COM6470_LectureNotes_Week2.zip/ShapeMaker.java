/*
	Make some shapes
 	Written by: Guy J. Brown
        First written: 27/9/02
        Last rewritten: 27/9/02
*/

import sheffield.*;

public class ShapeMaker {

	public static void main(String args[]) {

		EasyReader keyboard = new EasyReader();
		EasyGraphics g = new EasyGraphics(200,200);
		System.out.println("1 Rectangle");
		System.out.println("2 Square");
		System.out.println("3 Triangle");
		int shapeNum = keyboard.readInt("Choose a shape to draw: ");
		switch (shapeNum) {
			case 1: // rectangle
				g.moveTo(75,50); g.lineTo(125,50);
				g.lineTo(125,150); g.lineTo(75,150);
				g.lineTo(75,50);
				break;
			case 2: // square
				g.moveTo(50,50); g.lineTo(150,50);
				g.lineTo(150,150); g.lineTo(50,150);
				g.lineTo(50,50);
				break;
			case 3: // triangle
				g.moveTo(100,50); g.lineTo(150,150);
				g.lineTo(50,150); g.lineTo(100,50);
				break;
			default:
				System.out.println("Invalid shape!");
			}
		}
	}