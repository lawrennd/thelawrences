/*
        A first string example
        Written by: Guy J. Brown
        First written: 19/9/02
        Last rewritten: 19/9/02
*/

public class StringExample1 {

  public static void main(String[] args) {

		String s1 = "Hello";
		String s2 = "Hello Hello";
		String s3 = s1 + s2;
		String s4 = s1 + " " + s2;
		String s5 = "He said \"Hello\".";
		String s6 = "He said \"" + s4 + "\".";
		System.out.println(s6);

		}
	}
