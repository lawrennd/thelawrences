/*
	Sort two numbers - second version
 	Written by: Guy J. Brown
        First written: 27/9/02
        Last rewritten: 27/9/02
*/

import sheffield.*;

public class SortTwoNumbersTwo {

	public static void main(String[] args) {

		// variable declarations
		int first, second, larger, smaller, sum, difference;
		EasyReader keyboard = new EasyReader();

		// get two numbers from the keyboard
		first = keyboard.readInt("Enter first integer: ");
		second = keyboard.readInt("Enter second integer: ");

		// copy to larger and smaller
		if (first < second) {
			smaller = first;
			larger = second;
			}
		else {
			smaller = second;
			larger = first;
			}

		sum = larger+smaller;
		difference = larger-smaller;
		System.out.println("The sum is "+sum);
		System.out.println("The difference is "+difference);
		System.out.println("Larger is "+larger+" and smaller is "+smaller);
	}
}
