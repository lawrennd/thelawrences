/*
	Linear search on an array of integers
	Written by: Guy J Brown
	First written: 3/10/02
	Last rewritten: 3/10/02
*/

public class ArrayLinearSearch {

	public static void main (String[] args) {

		int[] dataItem = {24, 5, 6, 23, 42, 45, 2, 42, 1, 8};
		int position = 0;
		int soughtValue = 42;

    		while ((position<dataItem.length) && (dataItem[position]!=soughtValue)) {
			position++;
			}

		if (position<dataItem.length)
			System.out.println(soughtValue + " found at index "+ position);
		else
			System.out.println(soughtValue + " not found");
			
		for (int i=0; i<dataItem.length; i++) {
			if (dataItem[i]==soughtValue)
				System.out.println(soughtValue+" found at index "+i);
			}
		
  		}
	}