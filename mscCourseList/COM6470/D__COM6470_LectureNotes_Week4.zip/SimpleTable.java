/*
	Reads and writes a simple table of integers
	Written by: Guy J Brown
	First written: 9/9/98
	Last rewritten: 1/10/02
*/

import sheffield.*;

public class SimpleTable {
	public static void main(String[] args) {

		// streams for input and output

		EasyReader keyboard = new EasyReader();

		// create an array of user-defined size

		int numItems = keyboard.readInt("How many elements? ");
		int[] myArray = new int[numItems];

		// read the contents of the array

		for (int i=0; i<numItems; i++)
			myArray[i] = keyboard.readInt("Enter number "
																							+(i+1)+": ");

		// write the contents of the array

		System.out.println("Your numbers were:");
		for (int i=0; i<numItems; i++)
			System.out.println(myArray[i]);
		}
	}