/*
	Binary search on an array of integers
	Written by: Guy J Brown
	First written: 3/10/02
	Last rewritten: 3/10/02
*/

public class ArrayBinarySearch {

	public static void main (String[] args) {

		int[] dataItem = {1, 2, 5, 6, 8, 23, 24, 42, 45, 48};
		int soughtValue = 42;
		int first = 0; 
		int last = dataItem.length-1;
		int middle = 0;
		boolean found = false;
		while ((first <= last) && (!found)) {
			middle = (first+last)/2;
			if (dataItem[middle]>soughtValue)
				last = middle-1;
			else if (dataItem[middle]<soughtValue)
				first = middle+1;
			else 
				found = true;
			}

		if (found)
			System.out.println(soughtValue + " found at index " + middle);
		else
			System.out.println(soughtValue + " not found");
  		}

	}


