/*
	"Mod 2" Tesselation Automata
	Demonstrate the use of multi-dimensional arrays
	Written by: Guy J. Brown
	First written: 9/9/98
	Last rewritten: 2/10/02 
*/

import sheffield.*;

public class Tesselation {

	public static void main(String args[]) {
		
		final int MSIZE = 200;
		final int MAX_GENERATION = 50;

		// create a new graphics window
		
		EasyGraphics graphics = new EasyGraphics(MSIZE,MSIZE);
		
		// arrays to hold the old state and new state
		
		int[][] oldc = new int[MSIZE][MSIZE];
		int[][] newc = new int[MSIZE][MSIZE];
		
		// start with a lattice of all zeros, apart from
		// a one in the middle
		
		for (int i=0; i<MSIZE; i++)
			for (int j=0; j<MSIZE; j++)
				oldc[i][j]=0;
		oldc[MSIZE/2][MSIZE/2]=1;
		
		// k counts the generations
		
		for (int k=1; k<MAX_GENERATION; k++) {

			// set the new generation to all zeros
			for (int i=0; i<MSIZE; i++)
				for (int j=0; j<MSIZE; j++)
					newc[i][j]=0;

			// apply the rules for creating a new generation
			for (int y=1; y<MSIZE-1; y++)
				for (int x=1; x<MSIZE-1; x++) {
					int corth = oldc[x][y-1]+oldc[x][y+1]+oldc[x-1][y]+oldc[x+1][y];
					if ((k%2 == 0) && (corth==1))
						newc[x][y]=1;
					if (k%2 == 1) {
						int cdiag = oldc[x-1][y-1]+oldc[x-1][y+1]+oldc[x+1][y+1]+oldc[x+1][y-1];
						if ((corth+cdiag)==1) 
							newc[x][y]=1;
						}
					}
			// overlay the new generation on the old one
			for (int y=1; y<MSIZE-1; y++)
				for (int x=1; x<MSIZE-1; x++) 
					if (newc[x][y]==1)
						oldc[x][y]=1;
			}
		
		// display the pattern in the graphics window
		
		for (int y=0; y<MSIZE; y++) 
			for (int x=0; x<MSIZE; x++) 
				if (oldc[x][y]==1)
					graphics.plot(x,y);
		}
	}