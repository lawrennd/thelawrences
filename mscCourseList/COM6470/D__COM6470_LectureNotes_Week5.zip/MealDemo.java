/*
A demonstration of the Meal class
Author: Guy J. Brown
First written: 18/1/2001
Last modified: 18/1/2001
*/

public class MealDemo {

	public static void main(String[] args) {
		Meal stirFry = new Meal();
		stirFry.name="Vegetable Stir Fry";
		stirFry.price=4.99;
		stirFry.diet=Meal.VEGAN;
		stirFry.calories=400;
		Meal orangeDuck = new Meal();
		orangeDuck.name="Duck a L'Orange";
		orangeDuck.price=35.99;		
		
		System.out.println(stirFry);
		System.out.println(orangeDuck);
		}
		
	}