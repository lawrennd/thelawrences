/*
A class for representing a Meal
Author: Guy J. Brown
First written: 18/1/2001
Last modified: 18/1/2001
*/

public class Meal {

	/**
	* @author Guy J. Brown
	*/
	
	// class constants - enumeration for diet
	
	/**
	* @param diet
	*/
	static final int NORMAL = 0;
	
	/**
	* Normal diet
	*/
	static final int VEGAN = 1;
	
	/**
	* Normal diet
	*/
	static final int VEGETARIAN = 2;
	
	/**
	* Normal diet
	*/
	static final int UNSPECIFIED = 3;
		
	// attributes - we make them public only for demonstration purposes
	
	public int diet;
	public int calories;
	public double price;
	public String name;

	/**
	* Default constructor
	*/
	public Meal() {
		name="Unknown";
		price=0;
		calories=0;
		diet=UNSPECIFIED;
		}
		
	/**
	* Constructor
	* @param n name of meal
	* @param p price
	* @param c number of calories
	* @param d diet
	*/
	public Meal(String n, double p, int c, int d) {
		if (!validDiet(d)) {
			System.err.println("Invalid diet in constructor");
			System.exit(0);
			}
		name=n;
		price=p;
		calories=c;
		diet=d;
		}
				
	/**
	* Set the diet attribute
	* @param d diet
	*/
	public void setDiet(int d) {
		if (validDiet(d))
			diet=d;
		else {
			System.err.println("Invalid argument in setDiet");
			System.exit(0);
			}
		}
	
	/**
	* Set the name attribute
	* @param n name of meal
	*/
	public void setName(String n) {
		name=n;
		}
		
	/**
	* Set the calories attribute
	* @param c number of calories
	*/
	public void setCalories(int c) {
		calories=c;
		}
		
	/**
	* Set the price attribute
	* @param p price
	*/
	public void setPrice(double p) {
		price=p;
		}
		
	/**
	* Get the price attribute
	* @return price
	*/
	public double getPrice() {
		return price;
		}
		
	/**
	* Get the name attribute
	* @return name of the meal
	*/
	public String getName() {
		return name;
		}
		
	/**
	* Get the calories attribute
	* @return number of calories
	*/
	public int getCalories() {
		return calories;
		}
		
	/**
	* Get the diet attribute
	* @return diet
	*/
	public int getDiet() {
		return diet;
		}
		
	private boolean validDiet(int d) {
		return (d==NORMAL || d==VEGAN || d==VEGETARIAN);
		}
		
	private String getDietString() {
		String s="";
		switch(diet) {
			case NORMAL : s="normal"; break;
			case VEGAN : s="vegan"; break;
			case VEGETARIAN : s="vegetarian"; break;
			case UNSPECIFIED : s="unspecified";
			}
		return s;
		}
		
	/**
	* Get a string representation of a meal
	* @return a string representation of a meal
	*/
	public String toString() {
		return "Name="+name+" Diet="+getDietString()+" Calories="+calories+" Price="+price;
		}
				
	}